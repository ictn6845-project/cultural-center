
<footer>
    <p id="copyright">
        &copy; <?php echo date("Y"); ?> Pitt County Cultural Center. All Rights Reserved. <a href="<?php echo $app_path; ?>admin">Admin</a>
    </p>
</footer>

<!-- jQuery -->
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script>window.jQuery || document.write('<script src="js/libs/jquery-1.9.0.min.js">\x3C/script>')</script>

<script defer src="js/flexslider/jquery.flexslider-min.js"></script>

<!-- fire ups - read this file!  -->   
<script src="js/main.js"></script>

</body>
</html>