<?php include '../view/header.php'; ?>
<?php include '../view/sidebar.php'; ?>
<main class="nofloat">
    <h1>Contact Us</h1>
<img src="../images/3.jpg" width=73% height=73% border=1 vspace=3 alt="The Many Cultures Festival" align=left>
<p>
<i>A scene from our 2021 Many Cultures Festival.</i>  
    <p>Pitt County Cultural Center is open Tuesday through Saturday, from 10:00 AM to 5:00 PM Eastern Standard Time. The Center is located at 700 Arlington Avenue, west of Sumner Street.</p>
<ul>
<li>Phone (864) 232-9162</li>
<li>Email info@pittculturalcenter.org</li>
</ul>
Get in touch - we’d love to hear from you!

    </p>
</main>
<?php include 'view/footer.php'; ?>